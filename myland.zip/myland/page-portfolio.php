<?php
/*
Template Name: Наша работа
*/
?>


<?php

    get_header();

?>



<section class="work" id="work">
        <div class="container">
            <h2 class="title"><?php the_field('work_title')?></h2>
            <div class="work__wrapper">
            <div class="divider"></div>
            <div class="subtitle"><?php the_field('work_subtitle')?></div>
        
            <div class="work__text">Нажмите на картинку для просмотра</div>
        

            </div>   
        </div>
        </section>

        <section class="portfolio">
            <div class="container">
            <div class="row">
            <div class="col-md-12">
                <h3 class="portfolio__subtitle"><?php the_field('work_title1')?></h3>
                <div class="portfolio__descr"><?php the_field('work_subtitle1')?></div>
                <div class="portfolio__wrapper">

                    <a href="<?php the_field('sertifikat_img')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img1')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img1')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img2')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img2')?>" alt=""></a>
               
                </div>
                <div class="portfolio__wrapper">
                    <a href="<?php the_field('sertifikat_img3')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img3')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img4')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img4')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img5')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img5')?>" alt=""></a>
                </div>
                <div class="portfolio__wrapper">
                    <a href="<?php the_field('sertifikat_img6')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img6')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img7')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img7')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img8')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img8')?>" alt=""></a>
                </div>
                <div class="portfolio__wrapper">
                    <a href="<?php the_field('sertifikat_img9')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img9')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img10')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img10')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img11')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img11')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img12')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img12')?>" alt=""></a>
                </div>
                <div class="portfolio__wrapper">
                    <a href="<?php the_field('sertifikat_img13')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img13')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img14')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img14')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img15')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img15')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img16')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img16')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img17')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img17')?>" alt=""></a>
                </div>
                <div class="portfolio__wrapper">
                    <a href="<?php the_field('sertifikat_img18')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img18')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img19')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img19')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img20')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img20')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img21')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img21')?>" alt=""></a>
                    <a href="<?php the_field('sertifikat_img22')?>" data-lightbox="roadtrip"><img src="<?php the_field('sertifikat_img22')?>" alt=""></a>
                </div>
                
           
            </div>


            </div>
            </div>
                
                  

         
    </section>


<?php

    get_footer();

?>