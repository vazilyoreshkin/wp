<?php
/*
Template Name: Контакты
*/
?>

<?php

    get_header();

?>


<section class="contact">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="contact__blocks">
                                    <div class="contact__color">
                                        <h3 class="consultation__title consultation__title_main">Остались вопросы?</h3>
                                        <div class="consultation__subtitle">Напишите нам!</div>
                                            </div>
                                                <div class="contact__wrapper">
                                                    <?php echo do_shortcode('[contact-form-7 id="263" title="Форма запроса консультации1"]')?>
                                                </div>
                                            </div>   
                                    </div> 
                                </div>
                            </div>
                        </div>
                     </div>   
    </section>

    <section class="map" id="map">
        <script charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A2d1b1874b33b91f6e2767d400f26f49d7e66f2206b45dc5404e1000820709fec&amp;width=100%25&amp;height=400&amp;lang=ru_RU&amp;scroll=false"></script>
    </section>


<?php

    get_footer();

?>