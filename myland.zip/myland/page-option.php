<?php
/*
Template Name: Цены
*/
?>

<?php

    get_header();

?>


<section class="price" id="price">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="price__blocks">
                        <i class="fa fa-user" aria-hidden="true"></i>
                        <h2 class="title title_price"><?php the_field('price_title'); ?></h2>
                        <div class="descr"><?php the_field('podzagolovok_subtitle'); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="option">
        <div class="container">
                <h2 class="title"><?php the_field('ceni_title'); ?></h2>
            <div class="option__wrapper">
            <div class="divider"></div>
            <div class="subtitle"><?php the_field('ceni_subtitle'); ?><br></div>
            </div>
        </div>
    </section>

    <section class="tarif">
        <div class="container">
            <div class="row">
                    <div class="col-md-3">
                        <div class="tarif__wrapper">
                            <div class="tarif__item">
                                <div class="tarif__square">
                                    <div class="tarif__title"><?php the_field('zagolovok_title1'); ?></div>
                                </div>
                                <i class="fa fa-hourglass-start" aria-hidden="true"></i>
                                <div class="tarif__subtitle"><?php the_field('podzagolovok_title1'); ?></div>
                                <div class="tarif__price"><?php the_field('czena_descr1'); ?></div>
                                <div class="tarif__descr"><?php the_field('opisanie_descr1'); ?></div>
                                <button data-modal="consultation" class="button">подробнее</button>


                            </div>
                        </div>
                    </div>


                    <div class="col-md-3">
                        <div class="tarif__wrapper">
                            <div class="tarif__item">
                                <div class="tarif__square">
                                    <div class="tarif__title"><?php the_field('zagolovok_title2'); ?></div>
                                </div>
                                <i class="fa fa-trophy" aria-hidden="true"></i>
                                <div class="tarif__subtitle"><?php the_field('podzagolovok_title2'); ?></div>
                                <div class="tarif__price"><?php the_field('czena_descr2'); ?></div>
                                <div class="tarif__descr"><?php the_field('opisanie_descr2'); ?></div>
                                <button data-modal="consultation" class="button">подробнее</button>


                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="tarif__wrapper">
                            <div class="tarif__item">
                                <div class="tarif__square">
                                    <div class="tarif__title"><?php the_field('zagolovok_title3'); ?></div>
                                </div>
                                <i class="fa fa-tachometer" aria-hidden="true"></i>
                                <div class="tarif__subtitle"><?php the_field('podzagolovok_title3'); ?></div>
                                <div class="tarif__price"><?php the_field('czena_descr3'); ?></div>
                                <div class="tarif__descr"><?php the_field('opisanie_descr3'); ?></div>
                                <button data-modal="consultation" class="button">подробнее</button>


                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="tarif__wrapper">
                            <div class="tarif__item">
                                <div class="tarif__square">
                                    <div class="tarif__title"><?php the_field('zagolovok_title4'); ?></div>
                                </div>
                                <i class="fa fa-gift" aria-hidden="true"></i>
                                <div class="tarif__subtitle"><?php the_field('podzagolovok_title4'); ?></div>
                                <div class="tarif__price"><?php the_field('czena_descr4'); ?></div>
                                <div class="tarif__descr"><?php the_field('opisanie_descr4'); ?></div>
                                <button data-modal="consultation" class="button">подробнее</button>


                            </div>
                        </div>
                    </div>
           </div>
        </div>
    </section>
    <section class="consultation">
        <div class="container">
            <div class="row">
                <div class="col-md-12">

                    <div class="consultation__title">Заказать бесплатную консультацию</div>
                    <i class="fa fa-weixin" aria-hidden="true"></i>
                    <div class="consultation__wrapper">
                        <?php echo do_shortcode('[contact-form-7 id="263" title="Форма запроса консультации1"]')?> 
                    
                  
                </div>
               
            </div>
        </div>
    </section>
    
    <section class="price">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="price__blocks">
                        <i class="fa fa-users" aria-hidden="true"></i>
                        <h2 class="title title_price">Менеджеры компании</h2>
                        <div class="descr">Подберут для вас оптимальный вариант. Проведут консультацию и детально расскажут особенности по созданию проекта.</div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php

    get_footer();

?>