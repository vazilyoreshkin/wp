<?php
/*
Template Name: Схема работы
*/
?>


<?php

    get_header();

?>


<section class="scheme" id="scheme">
        <div class="container">
            <h2 class="title"><?php the_field('scheme_title'); ?></h2>
            <div class="row">

                <div class="col-md-3">
                    <div class="scheme__block">
                        <i class="fa fa-paper-plane-o" aria-hidden="true"></i>
                            <div class="scheme__descr">
                                <div class="scheme__subtitle"><?php the_field('scheme_title1'); ?></div>
                                <div class="scheme__desc"><?php the_field('scheme_desc1'); ?></div>
                            </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="scheme__block">
                        <i class="fa fa-calculator" aria-hidden="true"></i>
                            <div class="scheme__descr">
                                <div class="scheme__subtitle"><?php the_field('scheme_title2'); ?></div>
                                <div class="scheme__desc"><?php the_field('scheme_desc2'); ?></div>
                            </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="scheme__block">
                        <i class="fa fa-file-text" aria-hidden="true"></i>
                            <div class="scheme__descr">
                                <div class="scheme__subtitle"><?php the_field('scheme_title3'); ?></div>
                                <div class="scheme__desc"><?php the_field('scheme_desc3'); ?></div>
                            </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="scheme__block">
                        <i class="fa fa-rub" aria-hidden="true"></i>
                            <div class="scheme__descr">
                                <div class="scheme__subtitle"><?php the_field('scheme_title4'); ?></div>
                                <div class="scheme__desc"><?php the_field('scheme_desc4'); ?></div>
                            </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="scheme__block">
                        <i class="fa fa-cubes" aria-hidden="true"></i>
                            <div class="scheme__descr">
                                <div class="scheme__subtitle"><?php the_field('scheme_title5'); ?></div>
                                <div class="scheme__desc"><?php the_field('scheme_desc5'); ?></div>
                            </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="scheme__block">
                        <i class="fa fa-history" aria-hidden="true"></i>
                            <div class="scheme__descr">
                                <div class="scheme__subtitle"><?php the_field('scheme_title6'); ?></div>
                                <div class="scheme__desc"><?php the_field('scheme_desc6'); ?></div>
                            </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="scheme__block">
                        <i class="fa fa-rub" aria-hidden="true"></i>
                            <div class="scheme__descr">
                                <div class="scheme__subtitle"><?php the_field('scheme_title7'); ?></div>
                                <div class="scheme__desc"><?php the_field('scheme_desc7'); ?></div>
                            </div>
                    </div>
                </div>


                
            </div>
        </div>
    </section>


<?php

    get_footer();

?>