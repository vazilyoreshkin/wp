<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package myland
 */
?>

<?php
get_header();
?>
<body>
    
    <section class="promo" id="up" style="background-image: url('<?php  the_field('promo_img'); ?>')">
        
        
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="promo__descr"><?php the_field('promo_title'); ?></div>
                    <h1 class="promo__header"><?php the_field('promo_title1'); ?></h1>
                    <h2 class="promo__subheader"><?php the_field('promo_title2'); ?></h2>
                </div>
            </div>
        </div>
        <div class="promo__divider">
            <div class="promo__divider__title"></div>
        </div>
            <div class="row">
                <div class="col-sm-12 col-md-12">
                <div class="promo__wrapper">
                    <div class="promo__icons">
                        <div class="promo__icon">
                            <i class="fa fa-briefcase" aria-hidden="true"></i>
                        </div>
                        <div class="promo__icon_descr">Простое решение для малого и среднего бизнеса</div>
                    </div>

                    <div class="promo__icons">
                        <div class="promo__icon">
                            <i class="fa fa-rocket" aria-hidden="true"></i>
                        </div>
                        <div class="promo__icon_descr">Сайт под вашу услугу, с уникальным троговым предложением</div>
                    </div>

                    <div class="promo__icons">
                        <div class="promo__icon">
                            <i class="fa fa-thumbs-up" aria-hidden="true"></i>
                        </div>
                        <div class="promo__icon_descr">Выгодно и наглядно преподнесем ваше УТП</div>
                    </div>

                    <div class="promo__icons">
                        <div class="promo__icon">
                            <i class="fa fa-gift" aria-hidden="true"></i>
                        </div>
                        <div class="promo__icon_descr">Простое решение для малого и среднего бизнеса</div>
                    </div>
                </div>
            </div>
            </div>
                <button data-modal="consultation" class="button button_main">Получить расчет</button>
                
</section>
    
<?php
get_footer();
?>
