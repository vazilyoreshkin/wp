<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package myland
 */
?>
<div class="overlay">


<div class="modal" id="consultation">
    <div class="modal__close">&times;</div>
    <div class="modal__subtitle">Прост заполните форму заявки</div>
    <div class="modal__descr">И мы перезвоним вам в течении 10 минут</div>
    <form class="feed-form feed-form_mt25" action="#">
      <input name="name" placeholder="Ваше имя" type="text">
      <input name="phone" placeholder="Ваш телефон">
      <input name="email" placeholder="Ваш E-mail" type="email">
      <button class="button button_submit">Отправить заявку</button>
</form>
</div>

<div class="modal modal_mini" id="thanks">
    <div class="modal__close modal__close_min">&times;</div>
    <div class="modal__subtitle">Спасибо за вашу заявку</div>
    <div class="modal__descr">Наш менеджер свяжется с нами</div>
</div>
</div>
<a href ="#up" class="pageup">
<img src="<?php echo bloginfo('template_url'); ?>/assets/icons/up.svg" alt="up">
</a>
<footer class="footer">
        <div class="container">
            <div class="footer__info">
                <div class="row">
                    <div class="col-md-2">
                        <div class="header__logo"> <?php the_custom_logo(); ?></div>
                    </div>
                    <div class="col-md-4 offset-1">
                        <div class="footer__title"><?php the_field('slogan_footer', 2);?></div>
                    </div>
                    <div class="col-md-3">
                        <div class="footer__wrapper">
                        <div class="footer__call">Есть вопросы?</div>
                        <div class="footer__phone"><a href="tel:+79265668175"><?php the_field('phone', 2);?></a></div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <button data-modal="consultation" class="button button_footer button_media">Перезвоните мне</button>
                    </div>
                    <div class="col-md-12"><div class="footer__divider"></div></div>
                    <div class="col-12 col-md-2"><div class="footer__copyright">
                        &copy;&nbsp;2020&nbsp;Simple&nbsp;Land</div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="footer__politic"><a href="http://myland/privacy-policy/" target="_blank">Политика конфидециальности</a></div>
                    </div>
                    <div class="col-6 col-md-2 offset-3">
                        <div class="footer__like"><a href="mailto:vazily2015@gmail.com">Понравился сайт?</a></div>
                    </div>
                </div>
            </div>   
        </div>
            
    </footer>
    <?php
            wp_footer();
        ?>

</body>
</html>
