<?php
/*
Template Name: Преимущества
*/
?>


<?php

    get_header();

?>

        
<section class="reasons" id="reasons">
        <div class="container">
            <h2 class="title"><?php the_field('reasons_title'); ?></h2>
            <div class="reasons__wrapper">
                <div class="row">
                    <div class="col-12 col-md-6">
                        <div class="reasons__block">
                            <i class="fa fa-star" aria-hidden="true"></i>
                                <div class="reasons__descr">
                                    <div class="reasons__subtitle"><?php the_field('reasons_title1'); ?></div>
                                    <div class="reasons__desc"><?php the_field('reasons_desc1'); ?></div>
                                </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="reasons__block">
                            <i class="fa fa-cog fa-spin fa-3x fa-fw margin-bottom"></i>
                                <div class="reasons__descr">
                                    <div class="reasons__subtitle"><?php the_field('reasons_title2'); ?></div>
                                    <div class="reasons__desc"><?php the_field('reasons_desc2'); ?></div>
                                </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="reasons__block">
                            <i class="fa fa-graduation-cap" aria-hidden="true"></i>
                                <div class="reasons__descr">
                                    <div class="reasons__subtitle"><?php the_field('reasons_title3'); ?></div>
                                    <div class="reasons__desc"><?php the_field('reasons_desc3'); ?></div>
                                </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="reasons__block">
                            <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                <div class="reasons__descr">
                                    <div class="reasons__subtitle"><?php the_field('reasons_title4'); ?></div>
                                    <div class="reasons__desc"><?php the_field('reasons_desc4'); ?></div>
                                </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="reasons__block">
                            <i class="fa fa-smile-o" aria-hidden="true"></i>
                                <div class="reasons__descr">
                                    <div class="reasons__subtitle"><?php the_field('reasons_title5'); ?></div>
                                    <div class="reasons__desc"><?php the_field('reasons_desc5'); ?></div>
                                </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="reasons__block">
                            <i class="fa fa-rub" aria-hidden="true"></i>
                                <div class="reasons__descr">
                                    <div class="reasons__subtitle"><?php the_field('reasons_title6'); ?></div>
                                    <div class="reasons__desc"><?php the_field('reasons_desc6'); ?></div>
                                </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="reasons__block">
                            <i class="fa fa-puzzle-piece" aria-hidden="true"></i>
                                <div class="reasons__descr">
                                    <div class="reasons__subtitle"><?php the_field('reasons_title7'); ?></div>
                                    <div class="reasons__desc"><?php the_field('reasons_desc7'); ?></div>
                                </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="reasons__block">
                            <i class="fa fa-file-text-o" aria-hidden="true"></i>
                                <div class="reasons__descr">
                                    <div class="reasons__subtitle"><?php the_field('reasons_title8'); ?></div>
                                    <div class="reasons__desc"><?php the_field('reasons_desc8'); ?></div>
                                </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

<?php

    get_footer();

?>