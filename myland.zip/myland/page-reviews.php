<?php
/*
Template Name: Отзывы
*/
?>


<?php

    get_header();

?>

<section class="reviews" id="reviews">
        <div class="container">

        <h2 class="title">Отзывы клиентов</h2>
            <div class="option__wrapper">
            <div class="divider"></div>
            <div class="subtitle">Мы всегда стараемся помочь клиентам, что бы они обращались к нам снова</div>
            </div>

                <div class="carousel">

                    <div class="row">
                    <div class="col-md-12">
                    <div class="carousel__inner">
        <?php
                                // параметры по умолчанию
                        $posts = get_posts( array(
                            'numberposts' => -1,
                            'category_name'    => 'reviews',
                            'orderby'     => 'date',
                            'order'       => 'ASC',
                            'post_type'   => 'post',
                            'suppress_filters' => true, // подавление работы фильтров изменения SQL запроса
                        ) );

                        foreach( $posts as $post ){
                            setup_postdata($post);
                            ?>
                            <div><img src="<?php the_field('reviews_img'); ?>" alt="slide">
                                <div class="carousel__title"><?php the_title(); ?></div>
                                <div class="carousel__desc"><?php the_field('reviews_desc'); ?></div>
                            </div>


                             <?php
                            }

                            wp_reset_postdata(); // сброс
                            ?>
                       
                        
                    </div>
                    </div>
                    </div>

                </div>
        </div>
    </section>




<?php

    get_footer();

?>