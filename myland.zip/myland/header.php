<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package myland
 */

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Simple Land</title> 
    <meta name="description" content="НЕДОРОГОЙ ЛЕНДИНГ ПОД КЛЮЧ
    АДАПТИВНОСТЬ НА МОБИЛЬНЫХ УСТРОЙСТВАХ">

	<?php wp_head(); ?>
</head>
<header>
    <nav>
        <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
        </div>
        

    <div class="container">
        
            <div class="row">
                
                
                    <div class="col-12 col-sm-12 col-md-2">
                        <div class="header__logo"> <?php the_custom_logo(); ?></div>

                    </div>
                    <div class="col-12 col-md-6">
                            <?php

                                wp_nav_menu( [
                                    'menu'            => 'Main', 
                                    'container'       => false, 
                                    'menu_class'      => 'menu', 
                                    'echo'            => true,
                                    'fallback_cb'     => 'wp_page_menu',
                                    'items_wrap'      => '<ul class="menu">%3$s</ul>',
                                    'depth'           => 1,
                                ] );

                            ?>
                            </div>
                           
                            
                               
                    <div class="col-12 col-md-2">
                        <div class="menu__contact">
                            <div class="menu__call">Есть вопросы?</div>
                            <div class="menu__phone"><a href="tel:+79265668175"><?php the_field('phone', 2);?></a></div>
                        </div>
                    </div>
                    <div class="col-12 col-md-2">
                        <button data-modal="consultation" class="button button_media">Перезвоните мне</button>
                    </div>
                    
            </div>

    </div>
    </nav>
</header>
